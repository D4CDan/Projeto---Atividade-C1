const express = require('express')
const path = require('path')
const app = express()
const port = 3000

app.use(express.static(path.join(__dirname, 'public')))


app.get('/home', (req, res) => {
  res.sendFile(path.join(__dirname, 'public/index.html'))
})

app.get('/login', (req, res) => {
    res.sendFile(path.join(__dirname, 'public/login.html'))
  })

app.get('/password', (req, res) => {
    res.sendFile(path.join(__dirname, 'public/forgot-password.html'))
})

app.get('/register', (req, res) => {
    res.sendFile(path.join(__dirname, 'public/register.html'))
  })

app.listen(port, () => {
  console.log(`App de exemplo esta rodando na porta ${port}`)
})

